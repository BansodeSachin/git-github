package citi.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitiEurekaFastpassConsoleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitiEurekaFastpassConsoleApplication.class, args);
	}
}
