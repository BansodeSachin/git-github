import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Product{  
    int id;  
    String name;  
    int price;  
    public Product(int id, String name, int price) {  
        super();  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
} 

class PriceComparator implements Comparator<Product>{

	@Override
	public int compare(Product o1, Product o2) {
		return o1.price - o2.price;
	}
	
}

public class ListForEach {
	public static void main (String args[]) {
		
		Product p1 = new Product(1, "Apple", 100);
		Product p2 = new Product(2, "Grapes", 200);
		Product p3 = new Product(3, "Banana", 50);
		Product p4 = new Product(4, "Mangoes", 500);
		Product p5 = new Product(5, "Strawberry", 250);
		
		List<Product> list=new ArrayList();  
        list.add(p1);  
        list.add(p2);  
        list.add(p3);  
        list.add(p4);
        list.add(p5);
        
        Collections.sort(list, (a,b)->(a.price - b.price));
        //Collections.sort(list,(a,b)->new PriceComparator().compare(a, b));
        //Collections.sort(list, new PriceComparator()::compare);
        
        list.forEach(p -> System.out.println(p.name));
        
        System.out.println("*************************************");
        
        Collections.sort(list, (a,b)->{
        	return a.name.compareTo(b.name);
        });
        
        list.forEach(p -> System.out.println(p.name));
        
        System.out.println("*************************************");
        
        Stream<Product> filter = list.stream().filter(p -> p.price > 200);
        filter.forEach(p -> {
        	System.out.println(p.id + p.name + p.price);
        });  
        
        List<Product> product200 = list.stream().filter(p -> p.price > 200).collect(Collectors.toList());
        
        product200.forEach(s -> {
        	System.out.println(s.name.toUpperCase());
        });
     
        list.stream().filter(p->p.name.contains("es")).map(p->p.price).forEach(System.out::println);
        
        list.stream().limit(2).forEach(p -> System.out.println(p.name));
        
        System.out.println(list.stream().map(p->p.price).reduce(0,Integer::sum));
        
        System.out.println(list.stream().max((a,b)->(a.price-b.price)).get().name);
        
        Map<Integer,String> productPriceMap = list.stream().collect(Collectors.toMap(p->p.id, p->p.name));
        
        System.out.println(productPriceMap);
        
	}
}
