
public class DirtyCharacterForPalindrome {
	public static void main(String []args){
        
		DirtyCharacterForPalindrome classObj = new DirtyCharacterForPalindrome();
        
        String inputString = "cabdlac";
        
        if(!classObj.checkIfPalindrome(inputString)){
        
            int dirtyIndex = classObj.getIndexOfDirtyCharacter(inputString);
            
            if(dirtyIndex >=0 ){
                System.out.println(inputString + " will become palindrome if '"+inputString.charAt(dirtyIndex) + "' is removed from position "+(dirtyIndex+1));
            }else{
                 System.out.println(inputString + " is not at all a palindrome ");
            }
            
        }else{
            System.out.println(inputString + " is a palindrome ");
        }
        
    }
    
    public boolean checkIfPalindrome(String inputString){
        String reverseString = "";
        for (int idx = inputString.length()-1; idx >= 0; idx--){
           reverseString = reverseString + inputString.charAt(idx);    
        }
        return inputString.equals(reverseString);
    }
    
    public int getIndexOfDirtyCharacter(String inputString){
        char[] inputArray = inputString.toCharArray();
        for(int idx = 0; idx < inputArray.length; idx++){
            if(checkIfPalindrome(rewriteAfterOmitCharacter(idx, inputArray))){
               return idx; 
            }
        }
        return -1;
    }
    
    public String rewriteAfterOmitCharacter(int index, char[] inputArray){
        String newString = "";
        for(int idx=0 ; idx < inputArray.length; idx++){
            if(idx != index){
                newString = newString + inputArray[idx];
            }
        }
        return newString;
    }
}
