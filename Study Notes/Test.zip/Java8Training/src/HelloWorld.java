interface Drawable{  
    public void draw(String name);  
}

public class HelloWorld implements Calculate {

	public static int saySomething(){  
        return 0;  
    }  
	
	public static void main(String[] args) {
		
		System.out.println("Hello World");
		
		Drawable d2 = (name) -> {
			System.out.println("drawing with -> "+name);
		};
		
		d2.draw("kuldeep");
		
		Calculate add = (a,b)->(a+b);
		Calculate sub = (a,b)->(a-b);
		Calculate mul = (a,b)->(a*b);
		Calculate div = (a,b)->(a/b);
		
		System.out.println(add.engine(100, 200));
		System.out.println(sub.engine(200,100));
		System.out.println(mul.engine(100, 200));
		System.out.println(div.engine(200, 100));
		
		System.out.println(new HelloWorld().operand("+"));
		
		Calculate mod = (a, b)->{
			System.out.print(a + " % " + b + " = ");
			return a%b;
		};
		System.out.print(mod.engine(200, 100));
	}

	@Override
	public int engine(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}

@FunctionalInterface
interface Calculate {  
	
    int engine(int a,int b);
    
    default String operand(String opr) {
		return opr;
    }
    
    int hashCode();  
    
    String toString();  
    
    boolean equals(Object obj);  
}
