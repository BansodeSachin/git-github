import java.util.*;
import java.util.stream.*;
import java.util.Map;
import java.util.HashMap;
class Main {

    // fill in implementations for these methods

    public static boolean isBob(Person person) {
        // return true if this person's first name is "Bob", false otherwise
        if(person.firstName.equalsIgnoreCase("bob")){
          return true;
        }
        return false;
    }

    public static Map<Long, Person> bobMap(List<Person> people) {
        // return a Map of personNo -> Person only for people who's first name is "Bob"
        Map<Long, Person> bobPersonMap = new HashMap<Long, Person>();
        for(Person person : people){
          if(person != null){
            if(person.firstName.equalsIgnoreCase("bob")){
              bobPersonMap.put(person.personNo,person);
            }
          }
        }
        if(bobPersonMap.size() > 0){
          return bobPersonMap; 
        }
        return null;
    }

    public static void cleanNames(List<Person> people) {
        // change firstNames like "Bob" -> "Robert", "Tom" -> "Thomas", anything else leave alone
        for(Person person : people){
          if(person != null){
            if(person.firstName.equals("Bob")){
              person.firstName = "Robert";
            }
            if(person.firstName.equals("Tom")){
              person.firstName = "Thomas";
            }

          }  
        }
    }

    public static void removeRoberts(List<Person> people) {
        // remove people who's first name is "Robert"
        List<Person> withoutRobertPersonList = new ArrayList<Person>();
        for(Person person : people){
          if(person != null){
            if(!person.firstName.equals("Robert")){
              withoutRobertPersonList.add(person);      
            }
          }  
        }
        people.retainAll(withoutRobertPersonList);
    }

    // don't modify anything under here

    /*
    output should be like:
Person{personNo=1,firstName=Bob,lastName=Bobson} isBob: true
Person{personNo=2,firstName=Tom,lastName=Thompson} isBob: false
Person{personNo=3,firstName=Bob,lastName=Thompson} isBob: true
Person{personNo=4,firstName=Charley,lastName=Charleson} isBob: false
bobMap: {1=Person{personNo=1,firstName=Bob,lastName=Bobson}, 3=Person{personNo=3,firstName=Bob,lastName=Thompson}}
people before clean: [Person{personNo=1,firstName=Bob,lastName=Bobson}, null, Person{personNo=2,firstName=Tom,lastName=Thompson}, Person{personNo=3,firstName=Bob,lastName=Thompson}, Person{personNo=4,firstName=Charley,lastName=Charleson}]
people after clean: [Person{personNo=1,firstName=Robert,lastName=Bobson}, null, Person{personNo=2,firstName=Thomas,lastName=Thompson}, Person{personNo=3,firstName=Robert,lastName=Thompson}, Person{personNo=4,firstName=Charley,lastName=Charleson}]
people after removeRoberts: [null, Person{personNo=2,firstName=Thomas,lastName=Thompson}, Person{personNo=4,firstName=Charley,lastName=Charleson}]
    */

    public static void main(String[] args) {
        final Person bob = new Person(1, "Bob", "Bobson");
        final Person tom = new Person(2, "Tom", "Thompson");
        final Person bob2 = new Person(3, "Bob", "Thompson");
        final Person charley = new Person(4, "Charley", "Charleson");
        final List<Person> people = new ArrayList<>(Arrays.asList(bob, null, tom, bob2, charley));

        System.out.println(bob + " isBob: " + isBob(bob));
        System.out.println(tom + " isBob: " + isBob(tom));
        System.out.println(bob2 + " isBob: " + isBob(bob2));
        System.out.println(charley + " isBob: " + isBob(charley));
        System.out.println("bobMap: " + bobMap(people));

        System.out.println("people before clean: " + people);
        cleanNames(people);
        System.out.println("people after clean: " + people);

        removeRoberts(people);
        System.out.println("people after removeRoberts: " + people);
    }

    static class Person {
        long personNo;
        String firstName, lastName;

        Person(long personNo, String firstName, String lastName) {
            this.personNo = personNo;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public String toString() {
            return "Person{personNo=" + personNo +
                    ",firstName=" + firstName +
                    ",lastName=" + lastName +
                    "}";
        }
    }
}