import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SortMapByValue{

     public static void main(String []args){
         
         SortMapByValue classObj = new SortMapByValue();
         
         Map<String,Integer> map = classObj.initializeMap();
         
         Map<String,Integer> sortedMap = classObj.sortMapBasedOnValue(map);
         
         classObj.printMap(sortedMap);
     }
     
     public Map initializeMap(){
         Map<String,Integer> map = new HashMap<String,Integer>();
         map.put("ONE",new Integer(43));
         map.put("TWO",new Integer(85));
         map.put("THREE",new Integer(6));
         map.put("FOUR",new Integer(25));    
         return map;
     }
     
     public void printMap(Map<String,Integer> map){
         for(Map.Entry<String,Integer> entry : map.entrySet()) {
             System.out.println(entry.getKey() + "-" + entry.getValue());
         }
     }
     
     public Map sortMapBasedOnValue(Map<String,Integer> map){
         Map<String,Integer> sortedMap = new LinkedHashMap<String,Integer>();
         
         List<Entry<String,Integer>> entryList = new ArrayList<Entry<String,Integer>>(map.entrySet());
         
         Collections.sort(entryList, new Comparator<Entry<String,Integer>>(){
            public int compare(Entry<String,Integer> o1, Entry<String,Integer> o2) {
                return (o1.getValue()).compareTo(o2.getValue());
            }
         });
         
         for (Entry<String, Integer> entry : entryList) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }
         
         return sortedMap;
     }
     
}